﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EmoteHenery : MonoBehaviour
{
    public float pressedd;
    
    public SpriteRenderer emotedd;
    public Animator henery;
    public GameObject HenerygGO;
    

    public List<Sprite> myList = new List<Sprite>();

    // Start is called before the first frame update
    public void clickedd()
    {
        pressedd++;
    }

    // Update is called once per frame
    void Update()
    {
       

        
       
        if (pressedd == 10)
        {
            GetComponent<SpriteRenderer>().sprite = myList[10];
            emotedd.sprite = myList[10];
            
        }
        if (pressedd == 11)
        {
            GetComponent<SpriteRenderer>().sprite = myList[11];
            emotedd.sprite = myList[11];
            
        }
        if (pressedd == 7)
        {
            GetComponent<SpriteRenderer>().sprite = myList[7];
            emotedd.sprite = myList[7];
            HenerygGO.transform.eulerAngles = new Vector3(0, 172.499f, 0);
            Debug.Log(HenerygGO.transform.rotation);
        }


    }

    public void Start()
    {
        
    }


}
